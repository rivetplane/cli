# @rivetplane/sdk

The first-party TypeScript SDK for the Rivetplane control-plane API. It uses standard `fetch`, streams SSE without `EventSource`, and uses the standard `WebSocket` API. The same package works in Node.js 18 or later, Bun, and modern browsers.

## Install

```sh
npm install @rivetplane/sdk
```

## Use the REST API

```ts
import { Rivetplane } from "@rivetplane/sdk";

const rivetplane = new Rivetplane({
  baseUrl: "https://control.rivetplane.dev",
  authentication: process.env.RIVETPLANE_TOKEN!,
});

for (const session of await rivetplane.sessions.list({ status: "waiting_approval" })) {
  const pending = await rivetplane.sessions.pending(session.id);
  if (pending?.type === "approval") {
    await rivetplane.sessions.respondToPending(session.id, {
      pending_id: pending.id,
      response: "approve",
      scope: "once",
    });
  }
}
```

Authentication can be a token, a function, or an object with `getToken()`. Use a provider when tokens can rotate:

```ts
const rivetplane = new Rivetplane({
  baseUrl: "http://127.0.0.1:8080",
  authentication: async () => tokenStore.current(),
});
```

## Pagination and streaming

`transcriptPages()` gets all transcript pages lazily. `transcriptEvents()` flattens those pages. `streamTranscript()` reads live SSE events with an authenticated `fetch` call. Thus, it works in browsers where `EventSource` cannot set an authorization header.

```ts
for await (const event of rivetplane.sessions.transcriptEvents(sessionId, { limit: 100 })) {
  console.log(event.type, event.payload);
}

const controller = new AbortController();
for await (const event of rivetplane.sessions.streamTranscript(sessionId, { signal: controller.signal })) {
  console.log(event);
}
```

The account-wide WebSocket reconnects with exponential backoff by default. Browser authentication uses Rivetplane's `bearer.<base64url-token>` subprotocol.

```ts
for await (const event of rivetplane.events({
  reconnect: { initialDelayMs: 500, maxDelayMs: 10_000 },
})) {
  console.log(event.type, event.session_id);
}
```

Node.js 18 through 21 does not provide a global WebSocket. REST and SSE work without a polyfill. For account events, pass a WHATWG-compatible WebSocket constructor in `options.webSocket`. Node.js 22, Bun, and browsers provide one.

## Errors

Non-success HTTP responses throw `RivetplaneApiError`. It contains `status`, `method`, `url`, `body`, `requestId`, and `retryable`. Transport failures throw `RivetplaneNetworkError`. Invalid JSON or event data throws `RivetplaneProtocolError`.

See [`examples/basic.ts`](examples/basic.ts), [`examples/streaming.ts`](examples/streaming.ts), and [`docs/release.md`](docs/release.md).
